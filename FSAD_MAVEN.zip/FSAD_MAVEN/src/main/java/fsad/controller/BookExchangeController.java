package fsad.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import fsad.dto.BookDTO;
import fsad.entity.Books;
import fsad.entity.ExchangeRequests;
import fsad.entity.Message;
import fsad.entity.Users;
import fsad.mapper.BookMapper;
import fsad.service.BookService;
import fsad.service.ExchangeService;
import fsad.service.MessageService;
import fsad.service.UserService;

@RestController
@RequestMapping("/api")
public class BookExchangeController {
	
	@Autowired
    private UserService userService;
	@Autowired
    private BookService bookService;
	@Autowired
    private  ExchangeService exchangeService;
	@Autowired
    private  MessageService messageService;
	
	   @Autowired
	    private BookMapper bookMapper;

	/*
	 * public BookExchangeController(UserService userService, BookService
	 * bookService, ExchangeService exchangeService, MessageService messageService)
	 * { this.userService = userService; this.bookService = bookService;
	 * this.exchangeService = exchangeService; this.messageService = messageService;
	 * }
	 */
    // User Registration
    @PostMapping("/auth/register")
    public Users registerUser(@RequestBody Users user) {
        return userService.registerUser(user);
    }

    // Add Book Listing
    @PostMapping("/books")
    public Books addBook(@RequestBody Books book) {
        return bookService.addBook(book);
    }

    // Search Books
    @GetMapping("/books/search")
    public ResponseEntity<List<BookDTO>> searchBooks(@RequestParam(required = false) String title,
                                  @RequestParam(required = false) String author,
                                  @RequestParam(required = false) String genre) {
    	List<Books> books = bookService.searchBooks(title, author, genre);
    	
    	System.out.println("Fetched books: " + books);
        return ResponseEntity.ok(bookMapper.toDTOList(books));
    }
    
   
    // Create Exchange Request
    @PostMapping("/exchange-requests")
    public ExchangeRequests createExchangeRequest(@RequestBody ExchangeRequests exchangeRequest) {
        return exchangeService.createExchangeRequest(exchangeRequest);
    }

    // Send Message
    @PostMapping("/messages")
    public Message sendMessage(@RequestBody Message message) {
        return messageService.sendMessage(message);
    }
}
