package fsad.mapper;

import fsad.dto.ExchangeRequestsDTO;
import fsad.entity.ExchangeRequests;
import org.springframework.stereotype.Component;

@Component
public class ExchangeRequestsMapper implements GenericMapper<ExchangeRequests, ExchangeRequestsDTO> {

    @Override
    public ExchangeRequestsDTO toDTO(ExchangeRequests exchangeRequest) {
        ExchangeRequestsDTO dto = new ExchangeRequestsDTO();
        dto.setId(exchangeRequest.getId());
        dto.setBookId(exchangeRequest.getBook().getId()); // Assuming book has an ID
       // dto.setRequesterId(exchangeRequest.getRequester().getId()); // Assuming requester has an ID
        dto.setTerms(exchangeRequest.getTerms());
        dto.setStatus(exchangeRequest.getStatus());
        dto.setTimestamp(exchangeRequest.getTimestamp());
        return dto;
    }

    @Override
    public ExchangeRequests toEntity(ExchangeRequestsDTO dto) {
        ExchangeRequests exchangeRequest = new ExchangeRequests();
        // In this case, assuming book and requester entities are fetched by their ID.
        // You might need to load these entities from the database via a repository or service.
        // exchangeRequest.setBook(bookRepository.findById(dto.getBookId()).orElseThrow(...));
        // exchangeRequest.setRequester(userRepository.findById(dto.getRequesterId()).orElseThrow(...));

        exchangeRequest.setId(dto.getId());
        exchangeRequest.setTerms(dto.getTerms());
        exchangeRequest.setStatus(dto.getStatus());
        exchangeRequest.setTimestamp(dto.getTimestamp());
        return exchangeRequest;
    }
}
