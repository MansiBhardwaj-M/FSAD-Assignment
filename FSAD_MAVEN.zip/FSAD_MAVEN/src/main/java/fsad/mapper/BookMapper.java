
package fsad.mapper;

import org.springframework.stereotype.Component;

import fsad.dto.BookDTO;
import fsad.entity.Books;

@Component
public class BookMapper implements GenericMapper<Books, BookDTO> {

	@Override
	public BookDTO toDTO(Books book) {
		BookDTO dto = new BookDTO();
		dto.setId(book.getId());
		dto.setTitle(book.getTitle());
		dto.setAuthor(book.getAuthor());
		dto.setGenre(book.getGenre());
		dto.setAvailability(book.getAvailability());

		return dto;
	}

	@Override
	public Books toEntity(BookDTO dto) {
		Books book = new Books();
		book.setId(dto.getId());
		book.setTitle(dto.getTitle());
		book.setAuthor(dto.getAuthor());
		book.setGenre(dto.getGenre());
		book.setAvailability(dto.getAvailability());
		return book;
	}
}
