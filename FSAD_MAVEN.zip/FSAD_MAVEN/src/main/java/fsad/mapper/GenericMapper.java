package fsad.mapper;

import java.util.List;
import java.util.stream.Collectors;

public interface GenericMapper<E, D> {

    // Map a single entity to DTO
    D toDTO(E entity);

    // Map a single DTO to entity
    E toEntity(D dto);

    // Map a list of entities to DTOs
    default List<D> toDTOList(List<E> entities) {
        return entities.stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    // Map a list of DTOs to entities
    default List<E> toEntityList(List<D> dtos) {
        return dtos.stream()
                .map(this::toEntity)
                .collect(Collectors.toList());
    }
}
