package fsad.mapper;

import fsad.dto.MessageDTO;
import fsad.entity.Message;
import org.springframework.stereotype.Component;

@Component
public class MessageMapper implements GenericMapper<Message, MessageDTO> {

    @Override
    public MessageDTO toDTO(Message message) {
        MessageDTO dto = new MessageDTO();
        dto.setId(message.getId());
        //dto.setSenderId(message.getSender().getId()); // Assuming sender has an ID
        //dto.setReceiverId(message.getReceiver().getId()); // Assuming receiver has an ID
        dto.setContent(message.getContent());
        dto.setTimestamp(message.getTimestamp());
        return dto;
    }

    @Override
    public Message toEntity(MessageDTO dto) {
        Message message = new Message();
        // Fetch the sender and receiver entities by their IDs if required
        // message.setSender(userRepository.findById(dto.getSenderId()).orElseThrow(...));
        // message.setReceiver(userRepository.findById(dto.getReceiverId()).orElseThrow(...));
        
        message.setId(dto.getId());
        message.setContent(dto.getContent());
        message.setTimestamp(dto.getTimestamp());
        return message;
    }
}
