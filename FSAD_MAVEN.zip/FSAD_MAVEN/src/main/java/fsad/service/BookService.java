package fsad.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import fsad.entity.Books;
import fsad.entity.Users;
import fsad.repository.BookRepository;

@Service
public class BookService {
	
	@Autowired
    private  BookRepository bookRepository;

	/*
	 * public BookService(BookRepository bookRepository) { this.bookRepository =
	 * bookRepository; }
	 */

    public Books addBook(Books book) {
        return bookRepository.save(book);
    }

    public List<Books> getBooksByUser(Users user) {
        return bookRepository.findByOwner(user);
    }

    public List<Books> searchBooks(String title, String author, String genre) {
        // Implement your search logic here List<Book>
        return bookRepository.findAll();
    	//return "testing done";
    }
}
