package fsad.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import fsad.entity.ExchangeRequests;
import fsad.entity.Users;
import fsad.repository.ExchangeRequestRepository;

@Service
public class ExchangeService {
	@Autowired
	private  ExchangeRequestRepository exchangeRequestRepository;

	/*
	 * public ExchangeService(ExchangeRequestRepository exchangeRequestRepository) {
	 * this.exchangeRequestRepository = exchangeRequestRepository; }
	 */

	public ExchangeRequests createExchangeRequest(ExchangeRequests exchangeRequest) {
		return exchangeRequestRepository.save(exchangeRequest);
	}

	public List<ExchangeRequests> getExchangeRequestsByUser(Users user) {
		return exchangeRequestRepository.findByRequester(user);
	}
}
