package fsad.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import fsad.entity.Message;
import fsad.repository.MessageRepository;

@Service
public class MessageService {
	@Autowired
	private  MessageRepository messageRepository;

	/*
	 * public MessageService(MessageRepository messageRepository) {
	 * this.messageRepository = messageRepository; }
	 */

	public Message sendMessage(Message message) {
		return messageRepository.save(message);
	}

	public List<Message> getMessages(Long exchangeRequestId) {
		// Implement filtering by exchangeRequestId if required
		return messageRepository.findAll();
	}
}
