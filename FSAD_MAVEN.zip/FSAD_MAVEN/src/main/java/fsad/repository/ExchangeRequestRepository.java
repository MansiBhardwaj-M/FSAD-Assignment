package fsad.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import fsad.entity.ExchangeRequests;
import fsad.entity.Users;

public interface ExchangeRequestRepository extends JpaRepository<ExchangeRequests, Long> {

	List<ExchangeRequests> findByRequester(Users user);

}
