package fsad.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import fsad.entity.Books;
import fsad.entity.Users;

public interface BookRepository extends JpaRepository<Books, Long> {

	Books save(Books book);

	List<Books> findByOwner(Users user);

}
