package fsad.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import fsad.entity.Users;

public interface UserRepository extends JpaRepository<Users, Long> {}

