package FSAD_ASSIGNMENT.FSAD_MAVEN;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;


@SpringBootApplication
@ComponentScan({"FSAD-ASSIGNMENT.FSAD_MAVEN", "fsad.controller","fsad.entity","fsad.repository","fsad.service","fsad.mapper","fsad.dto"})
@EnableJpaRepositories(basePackages = "fsad.repository")
@EntityScan(basePackages = "fsad.entity") 
public class App {
    public static void main(String[] args) {
        SpringApplication.run(App.class, args);
    }
}
 