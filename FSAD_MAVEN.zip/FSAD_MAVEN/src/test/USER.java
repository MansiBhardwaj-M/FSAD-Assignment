package FSAD;

public class USER {

//	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		public class User {
//		    @Id
//		    @GeneratedValue(strategy = GenerationType.IDENTITY)
		    private Long id;
		    private String email;
		    private String password;
		    private String favoriteGenres;

		    // Getters and Setters
//		}

//	}

}
