import React from 'react';
import type { Book } from '../types';
import { useStore } from '../store/useStore';

interface BookCardProps {
  book: Book;
}

export function BookCard({ book }: BookCardProps) {
  const user = useStore((state) => state.user);
  const createRequest = useStore((state) => state.createRequest);

  const handleExchangeRequest = () => {
    if (!user) return;
    
    createRequest({
      id: Math.random().toString(),
      bookId: book.id,
      requesterId: user.id,
      ownerId: book.ownerId,
      status: 'Pending',
      message: `I'm interested in exchanging "${book.title}"`,
      createdAt: new Date(),
    });
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform hover:scale-105">
      <img
        className="h-48 w-full object-cover"
        src={book.coverUrl}
        alt={book.title}
      />
      <div className="p-4">
        <h3 className="text-lg font-semibold text-gray-900">{book.title}</h3>
        <p className="text-sm text-gray-600">{book.author}</p>
        <div className="mt-2 flex items-center">
          <span className="px-2 py-1 text-xs font-medium bg-indigo-100 text-indigo-800 rounded">
            {book.genre}
          </span>
          <span className="ml-2 px-2 py-1 text-xs font-medium bg-green-100 text-green-800 rounded">
            {book.condition}
          </span>
        </div>
        <p className="mt-2 text-sm text-gray-500 line-clamp-2">{book.description}</p>
        <button
          onClick={handleExchangeRequest}
          disabled={book.ownerId === user?.id}
          className="mt-4 w-full bg-indigo-600 text-white py-2 px-4 rounded-md hover:bg-indigo-700 disabled:bg-gray-300 disabled:cursor-not-allowed"
        >
          {book.ownerId === user?.id ? 'Your Book' : 'Request Exchange'}
        </button>
      </div>
    </div>
  );
}