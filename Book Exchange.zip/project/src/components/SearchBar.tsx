import React from 'react';
import { Search } from 'lucide-react';
import { useStore } from '../store/useStore';
import type { SearchFilters } from '../types';

export function SearchBar() {
  const searchFilters = useStore((state) => state.searchFilters);
  const searchBooks = useStore((state) => state.searchBooks);

  const handleSearch = (filters: Partial<SearchFilters>) => {
    searchBooks({ ...searchFilters, ...filters });
  };

  return (
    <div className="space-y-4">
      <div className="relative">
        <input
          type="text"
          placeholder="Search by title, author, or genre..."
          value={searchFilters.query}
          onChange={(e) => handleSearch({ query: e.target.value })}
          className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
        />
        <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
      </div>
      
      <div className="flex space-x-2 overflow-x-auto pb-2">
        {['All', 'Fiction', 'Non-Fiction', 'Mystery', 'Science Fiction', 'Romance'].map((genre) => (
          <button
            key={genre}
            onClick={() => handleSearch({ genre: genre === 'All' ? undefined : genre })}
            className={`px-4 py-2 text-sm font-medium rounded-full border 
              ${searchFilters.genre === genre
                ? 'bg-indigo-600 text-white border-transparent'
                : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'
              }`}
          >
            {genre}
          </button>
        ))}
      </div>
    </div>
  );
}