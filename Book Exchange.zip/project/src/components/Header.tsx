import React, { useState } from 'react';
import { BookOpen, Bell, LogIn } from 'lucide-react';
import { useStore } from '../store/useStore';
import { AuthModal } from './AuthModal';

export function Header() {
  const user = useStore((state) => state.user);
  const logout = useStore((state) => state.logout);
  const [showAuthModal, setShowAuthModal] = useState(false);

  return (
    <header className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <BookOpen className="h-8 w-8 text-indigo-600" />
            <span className="ml-2 text-xl font-bold text-gray-900">BookSwap</span>
          </div>
          
          <div className="flex items-center space-x-4">
            {user ? (
              <>
                <button className="p-2 rounded-full hover:bg-gray-100">
                  <Bell className="h-6 w-6 text-gray-600" />
                </button>
                
                <div className="flex items-center">
                  <img
                    className="h-8 w-8 rounded-full"
                    src={user.avatar}
                    alt={user.name}
                  />
                  <span className="ml-2 text-sm font-medium text-gray-700">
                    {user.name}
                  </span>
                </div>
                
                <button
                  onClick={() => logout()}
                  className="btn-secondary"
                >
                  Sign Out
                </button>
              </>
            ) : (
              <button
                onClick={() => setShowAuthModal(true)}
                className="btn-primary flex items-center"
              >
                <LogIn className="h-5 w-5 mr-2" />
                Sign In
              </button>
            )}
          </div>
        </div>
      </div>

      <AuthModal
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        mode="login"
      />
    </header>
  );
}