import React from 'react';
import { Header } from './components/Header';
import { SearchBar } from './components/SearchBar';
import { BookGrid } from './components/BookGrid';

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col space-y-8">
          <div className="flex flex-col space-y-4">
            <h1 className="text-3xl font-bold text-gray-900">
              Discover and Exchange Books
            </h1>
            <p className="text-gray-600">
              Connect with fellow readers and exchange your favorite books
            </p>
            
            <SearchBar />
          </div>
          
          <BookGrid />
        </div>
      </main>
    </div>
  );
}

export default App;