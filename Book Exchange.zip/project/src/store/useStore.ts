import { create } from 'zustand';
import type { Book, User, ExchangeRequest, Message, SearchFilters } from '../types';

interface Store {
  user: User | null;
  books: Book[];
  requests: ExchangeRequest[];
  messages: Message[];
  searchFilters: SearchFilters;
  
  // Auth actions
  setUser: (user: User | null) => void;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  
  // Book actions
  addBook: (book: Book) => void;
  updateBook: (book: Book) => void;
  deleteBook: (bookId: string) => void;
  searchBooks: (filters: SearchFilters) => Book[];
  
  // Exchange actions
  createRequest: (request: ExchangeRequest) => void;
  updateRequest: (request: ExchangeRequest) => void;
  getUserRequests: (userId: string) => ExchangeRequest[];
  
  // Message actions
  sendMessage: (message: Omit<Message, 'id' | 'timestamp'>) => void;
  getConversation: (userId1: string, userId2: string) => Message[];
  markMessageAsRead: (messageId: string) => void;
}

export const useStore = create<Store>((set, get) => ({
  user: null,
  books: [],
  requests: [],
  messages: [],
  searchFilters: {
    query: '',
    genre: undefined,
    condition: undefined,
    location: undefined,
    availability: true,
  },

  // Auth actions
  setUser: (user) => set({ user }),
  login: async (email, password) => {
    // Mock login - replace with actual API call
    const mockUser: User = {
      id: '1',
      name: 'John Doe',
      email,
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400',
      favoriteGenres: ['Fiction', 'Mystery'],
      location: 'New York, NY',
      joinedDate: new Date(),
      booksOwned: [],
      booksWishlist: [],
    };
    set({ user: mockUser });
  },
  logout: () => set({ user: null }),

  // Book actions
  addBook: (book) => set((state) => ({ 
    books: [...state.books, book],
    user: state.user ? {
      ...state.user,
      booksOwned: [...state.user.booksOwned, book.id]
    } : null
  })),
  updateBook: (book) => set((state) => ({
    books: state.books.map((b) => (b.id === book.id ? book : b))
  })),
  deleteBook: (bookId) => set((state) => ({
    books: state.books.filter((b) => b.id !== bookId),
    user: state.user ? {
      ...state.user,
      booksOwned: state.user.booksOwned.filter((id) => id !== bookId)
    } : null
  })),
  searchBooks: (filters) => {
    const { books } = get();
    return books.filter((book) => {
      const matchesQuery = !filters.query || 
        book.title.toLowerCase().includes(filters.query.toLowerCase()) ||
        book.author.toLowerCase().includes(filters.query.toLowerCase());
      const matchesGenre = !filters.genre || book.genre === filters.genre;
      const matchesCondition = !filters.condition || book.condition === filters.condition;
      const matchesLocation = !filters.location || book.location === filters.location;
      const matchesAvailability = !filters.availability || book.status === 'Available';
      
      return matchesQuery && matchesGenre && matchesCondition && 
             matchesLocation && matchesAvailability;
    });
  },

  // Exchange actions
  createRequest: (request) => set((state) => ({
    requests: [...state.requests, request]
  })),
  updateRequest: (request) => set((state) => ({
    requests: state.requests.map((r) => (r.id === request.id ? request : r))
  })),
  getUserRequests: (userId) => {
    const { requests } = get();
    return requests.filter((r) => 
      r.requesterId === userId || r.ownerId === userId
    );
  },

  // Message actions
  sendMessage: (message) => set((state) => ({
    messages: [...state.messages, {
      ...message,
      id: Math.random().toString(),
      timestamp: new Date(),
    }]
  })),
  getConversation: (userId1, userId2) => {
    const { messages } = get();
    return messages.filter((m) => 
      (m.senderId === userId1 && m.receiverId === userId2) ||
      (m.senderId === userId2 && m.receiverId === userId1)
    ).sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());
  },
  markMessageAsRead: (messageId) => set((state) => ({
    messages: state.messages.map((m) => 
      m.id === messageId ? { ...m, read: true } : m
    )
  })),
}));