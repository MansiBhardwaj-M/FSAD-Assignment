export interface User {
  id: string;
  name: string;
  email: string;
  avatar: string;
  favoriteGenres: string[];
  location: string;
  joinedDate: Date;
  booksOwned: string[];
  booksWishlist: string[];
}

export interface Book {
  id: string;
  title: string;
  author: string;
  genre: string;
  condition: 'New' | 'Like New' | 'Very Good' | 'Good' | 'Fair';
  coverUrl: string;
  ownerId: string;
  status: 'Available' | 'Pending' | 'Exchanged';
  description: string;
  location: string;
  listingDate: Date;
}

export interface ExchangeRequest {
  id: string;
  bookId: string;
  requesterId: string;
  ownerId: string;
  status: 'Pending' | 'Accepted' | 'Rejected' | 'Completed';
  message: string;
  createdAt: Date;
  deliveryMethod: 'In Person' | 'Mail';
  duration: number; // in days
  meetingLocation?: string;
  trackingNumber?: string;
}

export interface Message {
  id: string;
  senderId: string;
  receiverId: string;
  content: string;
  timestamp: Date;
  requestId?: string;
  read: boolean;
}

export type SearchFilters = {
  query: string;
  genre?: string;
  condition?: string;
  location?: string;
  availability?: boolean;
};